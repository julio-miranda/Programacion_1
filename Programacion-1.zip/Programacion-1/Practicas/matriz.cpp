//Programa creado por: Julio Armando Miranda Reyes 
//Carnet: MR18031

//librerias utilizadas
#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;
	
	
	int main(){
		srand(time(NULL));
		int matriz[3][3];
		for(int i=0;i<3;i++){
			for (int j=0;j<3;j++){
				matriz[i][j]=rand()%101;
				if (matriz [i][j]%2!=0){
					cout<<matriz[i][j]<< " - " ;
				}else{
					cout<< " - "<<" - ";
				}
			}
			cout<<endl;
		
		}
		return 0;
	}
