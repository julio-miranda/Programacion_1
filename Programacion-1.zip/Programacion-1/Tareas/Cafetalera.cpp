//Este programa tiene la funcion de calculare total de venta aplicando descuentos y iva usando el "if".
//hecho por : Julio Armando Miranda Reyes.
#include <iostream> 
#include <math.h>

using namespace std;

int main() {
	
	float iva, s1, d1, suma1, suma2;
	
	cout<<"El total de Sacos:";
	cin>>s1;
	
iva=(s1*0.13);

if(s1>100) {
	d1=(s1*(0.10));
	suma1=s1-d1;
	suma2=s1+iva;	
	cout<<"El precio del producto al aplicarle el descuento:" <<suma1<<endl;
	cout<<"El precio del producto al aplicarle el iva:" <<suma2<<endl;
}
else if(s1>200) {
	d1=(s1*(0.15));
	suma1=s1-d1;
	suma2=s1+iva;	
	cout<<"El precio del producto al aplicarle el descuento:"<<suma1<<endl;
	cout<<"El precio del producto al aplicarle el iva:"<<suma2<<endl;
}
else if(s1>250 && s1<300) {
	d1=(s1*(0.20));
	suma1=s1-d1;
	suma2=s1+iva;	
	cout<<"El precio del producto al aplicarle el descuento:"<<suma1<<endl;
	cout<<"El precio del producto al aplicarle el iva:"<<suma2<<endl;
}
else if(s1>=300) {
	d1=(s1*(0.25));
	suma1=s1-d1;
	suma2=s1+iva;	
	cout<<"El precio del producto al aplicarle el descuento:"<<suma1<<endl;
	cout<<"El precio del producto al aplicarle el iva:"<<suma2<<endl;
}
	return 0;
}
