//Este programa tiene la funcion "while" y "if".
//hecho por : Julio Armando Miranda Reyes
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <MMSystem.h>

using namespace std;  

int main(){
	
	PlaySound(TEXT("Sonido.wav"), NULL, SND_SYNC);

	//Nuevo color del sistema
	system("color 9F");
	
	//Variables necesarias
	int ventas=0;//un dato flotante
	
	float salario;//un dato flotante
	
	do{		
		cout<<"Escriba el numero de venta: ";//Escriba el dato necesario
		cin>> ventas;
		cout<<" "<<endl;
		}
		while(ventas <= 0); //funcion para evitar numeros negativos en el sistema;
		
		if(ventas<=500000) {//si es menor o igual de 500000 el sueldo sera de 80.000
		
		cout<<"Su sueldo sera de: "<<"80.000"<<endl;
		cin>>salario;
		 }
		 
		 else if(ventas<=1000000){//si es menor o igual de 1000000 el sueldo sera de 160.000
		 
		 cout<<"Su sueldo sera de: "<<"160.000"<<endl;
		 cin>>salario;
		 }
		 
		 else if(ventas<=1500000){//si es menor o igual de 1500000 el sueldo sera de 320.000
		 
		 cout<<"Su sueldo sera de: "<<"320.000"<<endl;
		 cin>>salario;
		 }
		 
		 else if(ventas<=2500000){//si es menor o igual de 2500000 el sueldo sera de 450.000
		 
		 cout<<"Su sueldo sera de: "<<"450.000"<<endl;
		 cin>>salario;
		 }
		 else if(ventas<=4000000){//si es menor o igual de 4000000 el sueldo sera de 550.000
		 	
		 cout<<"Su sueldo sera de: "<<"550.000"<<endl;
		 }
		 else{// La finalizacion
		 	
		 salario=(ventas*0.20);//multiplicacion por el 20% 
		 
		 cout<<fixed<<setprecision(3)<<"Tu sueldo sera de el 20% de las ventas realizadas: "<<salario<<endl; //impresion de los datos si es mayor de 4000000
		 
		 }
system ("pause");

return 0;
}
