//Este programa fue hecho por: Julio Miranda
#include <iostream>
#include <iomanip> 

using namespace std;

void limpieza();//para limpiar el codigo
void p();


int main(int argc, char** argv) {
	
        //variables 
        float costo;
	int min;
	
	do{
		//introduzca los minutos de la llamada
                cout<<"Introduzca los minutos de la llamada: ";
		cin>>min; 
		limpieza();//para limpiar el codigo
	} while (min<=0);
	
		if (min<=10){
		costo=0.05;
                //el numero total a pagar
		cout<<"El total a pagar es de: $"<<fixed<<setprecision(2)<<costo<<endl;
		p();
		limpieza();//para limpiar el codigo
	} else if(min<=15){
		costo=0.08;
                //el numero total a pagar
		cout<<"El total a pagar es de: $"<<fixed<<setprecision(2)<<costo<<endl;
		p();
		limpieza();//para limpiar el codigo
	} else {
		costo=0.10;
                //el numero total a pagar
		cout<<"El total a pagar es de: $"<<fixed<<setprecision(2)<<costo<<endl;
		p();
		limpieza();//para limpiar el codigo
	}
	
	
	
	return 0;
}

void limpieza(){//para limpiar el codigo
	system ("cls");
}

void p(){
	system("pause");
}
