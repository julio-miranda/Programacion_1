//Este programa fue hecho por: Julio Miranda
#include <iostream>
#include <windows.h>

using namespace std;

void cl();
int soda(int sa, int s);
int sod(int saz, int s);
int jugo(int ja, int j);
int jug(int jaz, int j);
void sy();

int main(){
	//declaracion de variables necesarias
	int in;
	int s;
	int j;
	int sa=500;
	int saz=800;
	int ja=600;
	int jaz=700;
	}
	//inicio de do para empezar el ciclo
	do{
	//ingreso de datos
	cout<<"�Que tipo de bebida deseas calcular sus insumos?"<<endl;
	cout<<"1- Sodas."<<endl;//es para ver si son sodas
	cout<<"2- Jugos."<<endl;//es para ver si son jugos
	cin>>in;
	cl();
	} while(in<1 || in>2);// inicio del ciclo while		

	//si son sodas entonces esta funcion se cumplira
	if (in==1){//ingreso de la cantidad de sodas
		cout<<"�Cuantas sodas se producieron?"<<endl;
		cin>>s;
		cl();
		sa=soda(sa,s);
		saz=sod(saz,s);
		cout<<"Los insumos total para la elaboracion de sodas del dia fueron:"<<endl;//la afirmacion de la cantidad de insumos usados
		cout<<"Agua: "<<sa<<" ml de agua."<<endl;//cantidad de agua usada
		cout<<"Azucar: "<<saz<<"gr de azucar."<<endl;//cantidad de azucar usada
		sy();
		cl();
	
	//si son jugos entonces esta funcion se cumplira
	} else {
		//ingreso de la cantidad de jugos
		cout<<"�Cuantos jugos se producieron?"<<endl;
		cin>>j;
		cl();
		ja=jugo(ja,j);
		jaz=jug(jaz,j);
		cout<<"Los insumos total para la elaboracion de jugos del dia fueron:"<<endl;//la afirmacion de la cantidad de insumos usados
		cout<<"Agua: "<<ja<<" ml de agua."<<endl;//cantidad de agua usada
		cout<<"Azucar: "<<jaz<<" gr de azucar."<<endl;//cantidad de azucar usada
		sy();
		cl();
		
	}
	
	return 0;//fin del ciclo
}

void cl(){//para limpiar el sistema
	system("cls");
}

int soda(int sa, int s){
	

	return sa*s;//fin dela funcion
}
int sod(int saz, int s){
	

	return saz*s;//fin dela funcion
}

int jugo(int ja, int j){
	
	return ja*j;//fin dela funcion
}

int jug(int jaz, int j){
	
	return jaz*j;//fin dela funcion
}

void sy(){//fin dela funcion
	system("pause");
}
