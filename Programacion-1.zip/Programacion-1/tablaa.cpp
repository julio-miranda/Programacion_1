//Programa creado por: Julio Armando Miranda Reyes
//Carnet: MR18031

//librerias utilizadas
#include <iostream> //utilizado para operaciones de entrada/salida.
#include <math.h>	//utilizado para procesos matematicos.
#include <windows.h> //utilizado para declarar las funciones de la biblioteca windows API.

//cuerpo del programa
using namespace std;

int main (int argc, char *argv[]){

for (int i=1;i<=10;i++)
{				
cout<<endl<<("La tabla del ")<<i<<endl;

for (int j=1;j<=10;j++)

cout<<i<<"x"<<j<<"="<<i*j<<endl;

 }

system("pause");
return 0;

}

